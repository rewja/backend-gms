<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('todos', function (Blueprint $table) {
            if (!Schema::hasColumn('todos', 'recurrence_start_date')) {
                $table->date('recurrence_start_date')->nullable()->after('due_date');
            }
            if (!Schema::hasColumn('todos', 'recurrence_interval')) {
                $table->unsignedInteger('recurrence_interval')->nullable()->after('recurrence_start_date');
            }
            if (!Schema::hasColumn('todos', 'recurrence_unit')) {
                $table->enum('recurrence_unit', ['day','week','month','year'])->nullable()->after('recurrence_interval');
            }
            if (!Schema::hasColumn('todos', 'recurrence_count')) {
                $table->unsignedInteger('recurrence_count')->nullable()->after('recurrence_unit')->comment('0 means unlimited');
            }
        });
    }

    public function down(): void
    {
        Schema::table('todos', function (Blueprint $table) {
            if (Schema::hasColumn('todos', 'recurrence_start_date')) {
                $table->dropColumn('recurrence_start_date');
            }
            if (Schema::hasColumn('todos', 'recurrence_interval')) {
                $table->dropColumn('recurrence_interval');
            }
            if (Schema::hasColumn('todos', 'recurrence_unit')) {
                $table->dropColumn('recurrence_unit');
            }
            if (Schema::hasColumn('todos', 'recurrence_count')) {
                $table->dropColumn('recurrence_count');
            }
        });
    }
};








